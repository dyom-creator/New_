function preload(){
  
}

function setup() {
  createCanvas(400, 400);
  background(220);
  ellipse(200, 200, 200, 200);
  arc(200,200,100,100,0,PI);
  point(150,180);
  point(250,180);
  line(180,200,220,200);
  
 
}

function draw() {
  //background(220);
  //ellipse(200, 200, 200, 200);
  //arc(200,200,100,100);
}